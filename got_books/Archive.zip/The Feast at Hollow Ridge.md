---
author: Alex J. Padin
contributor: "ChatGPT (based on user's request)"
date: "2025-04-28T07:00:00+00:00"
description: |
  ORIGINAL STORY:

  Set in a world inspired by Westeros, this tale follows the fearless knight Illary and her loyal lab mix Tego, alongside shy Prince Alex and his food-loving pug Frankie. When danger stirs in the forgotten woods of Hollow Ridge, bonds are tested in flame and shadow. What begins as a simple scent leads to an encounter with ancient creatures, forgotten magic, and a deeper threat stirring beneath the trees. A high fantasy adventure with charm, danger, and two very determined dogs.

identifier:
- frankie-tego-adventure-001
language: en
publisher: None
subject: Fantasy, Adventure, Animals
title: The Feast at Hollow Ridge
---

# The Feast at Hollow Ridge

The morning mist curled low over the valley when Frankie found the first scent—meaty, rich, mysterious. His short legs powered forward at a wobbling gallop, tongue flapping, nose wet and wild with purpose.

Tego didn’t move at first. The lab mix stood sentinel atop a mossy ridge, ears perked, eyes scanning the woods below. He had been watching the clearing for an hour, silent and still as a stone. When Frankie snorted and took off through the ferns, Tego sighed and followed.

> “Frankie,” Tego growled softly, “slow down. You don’t know what’s out here.”

> “I *do* know,” the pug panted, pushing past branches. “I smell ribs.”

Tego caught up easily, his long strides quiet, practiced. “That’s not ribs. That’s… something else.”

Frankie ignored him. “Definitely ribs.”

They reached the hollow by midmorning. Sunlight spilled down in thin shafts through the trees, and the scent was stronger now—charred, earthy, not quite right. Tego crouched low behind a log, watching the open ground below. A small wooden cart lay tipped on its side, wheels cracked, and something blackened smoldered in a pit near it. Smoke curled upward in lazy spirals.

> “That’s a hunter’s cart,” Tego said. “But it’s been abandoned.”

> “I think he forgot his lunch,” Frankie said, inching forward, drool already puddling in the dirt.

But the forest was too quiet. No birdsong. No insects. Just the whisper of wind through dead branches.

> “We shouldn’t be here,” Tego warned.

Then came the crack of a twig.

Frankie froze. Tego was already standing between him and the sound, his shoulders squared. Something moved in the brush—low, crawling, slow. Not a deer. Not a man. A shape too long. A smell too foul.

> “Back,” Tego barked.

Too late. The thing burst from the thicket, all teeth and hunger. A woodshade—forest-born, blind, and starving. Tego lunged.

The clash was fast and loud. Tego slammed into the creature’s side, jaws snapping, paws tearing up the soil. Frankie scrambled away, barking wildly. He didn’t know what it was, but he knew Tego was fighting it. And Tego never lost.

But this time, it wasn’t just one.

Another shape slithered from the trees. Then a third.

> “*TEGO!*” Frankie yelped.

And then—just when it seemed the monsters would close in—there was a roar from above. Not an animal’s roar. A machine.

A blur dropped from the treeline, silver armor flashing, blade drawn.

**Illary.**

She hit the ground hard, rolled to her feet, and carved the nearest woodshade in half. “Back to the mud, you filth,” she spat, spinning, fast and graceful and furious.

Behind her, another voice called out—less graceful, more exasperated.

> “Is that *Frankie* down there? *Frankie!* You were supposed to stay on the porch!”

**Alex** came stumbling out of the trees, mud up to his knees, one boot missing, holding a frying pan.

> “Why would I stay on the porch if there were ribs out here?” Frankie muttered.

Illary had already cut down a second beast. The third turned and fled.

Tego stood, panting hard, blood on his muzzle but still steady. Frankie waddled over, tail wagging.

> “Are you okay?” he asked.

> “I’ve had worse,” Tego muttered.

Illary knelt down, wiped her blade, and scratched behind his ears.

> “Good boy.”

Tego’s whole body wagged.

Frankie bounded toward her too, pressing his face into her lap.

> “*You’re* the best.”

Alex finally arrived, wheezing and holding out a handful of cheese.

> “Anyone want a snack?”

> “It’s not ribs,” Frankie muttered.

---

They sat for a while beside the smoldering pit. Illary examined the cart. It bore no sigil—just the crude carvings of protective runes long faded.

> “This wasn’t a hunter,” she said. “This was a warding cart. They used these decades ago to trap the old ones deeper in the forest.”

> “So this was on purpose?” Alex asked.

> “Or sabotage,” she said. “Either way, someone led those creatures out.”

Alex shivered. “I liked it better when the worst we had to deal with was Frankie stealing roasted chicken.”

Frankie grunted. “That chicken was unattended.”

Tego raised his snout. “There’s something buried under the cart.”

They dug it out together—a dark wooden box, sealed with iron and covered in dust. Illary cracked it open.

Inside lay an orb. Faintly glowing. Breathing, almost.

> “That’s a heartstone,” Illary whispered. “But it’s awake.”

Tego growled, backing away. Even Frankie took a step back.

Alex stood behind Illary, half hiding, half curious.

> “What does it do?”

> “It remembers,” she said. “Old magic. The kind that speaks to beasts.”

She wrapped it in cloth and stowed it in her satchel.

> “We can’t leave it here. It’ll keep drawing the woodshades.”

> “So we take it back to the keep?” Alex asked.

> “No,” she said. “We take it to the Cliff of Embers. Toss it into the sea.”

> “That’s two days from here,” Tego said. “And we’re not alone.”

---

By dusk, they’d made camp beneath a rocky overhang. Illary sat sharpening her blade. Tego stood watch.

Frankie lay curled in a blanket beside Alex, who was scribbling in a little leather notebook.

> “What are you writing?” Frankie asked, licking crumbs from his chin.

> “Just… today,” Alex said. “What we saw. How you nearly got eaten.”

Frankie snorted. “You say it like that wasn’t part of the plan.”

Alex smiled. Just a little.

Illary spoke without looking up. “Tomorrow, we follow the ridge path. It’s narrow. Dangerous.”

> “And filled with ribs?” Frankie asked hopefully.

> “Filled with cliffs,” Tego corrected. “So no falling behind.”

They all fell quiet as night settled in. The fire crackled low.

Above them, something howled in the dark.

Tego didn’t sleep that night.

---

They reached the Cliff of Embers by the second day’s end. The sea roared below like a thousand ancient dragons exhaling together. Illary stood at the edge, the wrapped stone in her hands.

> “You sure this will stop it?” Alex asked.

> “No,” she said. “But it’s the only thing we can do.”

She hurled the stone into the waves. It vanished into the deep. For a moment, nothing.

Then a tremor underfoot. A long, distant groan from beneath the sea.

Then stillness.

It was done.

---

They returned a week later. Frankie got his ribs. Tego got a new collar. Alex went back to writing. Illary? She was already packing for her next patrol.

But they all agreed on one thing: Frankie was never allowed to follow his nose unsupervised again.

> “Even if it smells like ribs?” Frankie asked.

> “Especially if it smells like ribs,” Tego said.

And Frankie, tail wagging, made no promises.
